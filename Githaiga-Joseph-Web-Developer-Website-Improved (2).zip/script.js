"use strict";

/* ---------- Settings: change your number here ONLY ---------- */
const WHATSAPP_NUMBER = "254746380982"; // international format, no + or spaces
const DISPLAY_PHONE = "0746 380 982";
/* ------------------------------------------------------------ */

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

const waLink = (text) =>
  `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(text)}`;

/* Keep every WhatsApp / phone link in sync with the settings above */
$$("[data-wa]").forEach((a) => (a.href = waLink(a.dataset.wa)));
$$("[data-phone]").forEach((a) => {
  a.href = `tel:+${WHATSAPP_NUMBER}`;
  a.textContent = DISPLAY_PHONE;
});

/* Footer year */
$("#year").textContent = new Date().getFullYear();

/* ---------- Header: shadow after scrolling ---------- */
const header = $("#siteHeader");
const onScroll = () => header.classList.toggle("scrolled", window.scrollY > 10);
onScroll();
window.addEventListener("scroll", onScroll, { passive: true });

/* ---------- Mobile menu ---------- */
const toggle = $("#menuToggle");
const navLinks = $("#navLinks");

function setMenu(open) {
  navLinks.classList.toggle("open", open);
  toggle.classList.toggle("open", open);
  toggle.setAttribute("aria-expanded", String(open));
  toggle.setAttribute("aria-label", open ? "Close menu" : "Open menu");
  document.body.classList.toggle("menu-open", open);
}

toggle.addEventListener("click", () => setMenu(!navLinks.classList.contains("open")));
$$("a", navLinks).forEach((a) => a.addEventListener("click", () => setMenu(false)));
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") setMenu(false);
});
window.matchMedia("(min-width: 851px)").addEventListener("change", () => setMenu(false));

/* ---------- Highlight the nav link of the section in view ---------- */
const sections = $$("main section[id]");
const linkFor = (id) => $(`.nav-links a[href="#${id}"]`);

if ("IntersectionObserver" in window) {
  const spy = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        $$(".nav-links a").forEach((a) => a.classList.remove("active"));
        const link = linkFor(entry.target.id);
        if (link) link.classList.add("active");
      });
    },
    { rootMargin: "-45% 0px -50% 0px" }
  );
  sections.forEach((s) => spy.observe(s));
}

/* ---------- Floating WhatsApp button: show after the hero ---------- */
const waFloat = $("#waFloat");
const hero = $("#home");
if ("IntersectionObserver" in window) {
  new IntersectionObserver(
    ([entry]) => waFloat.classList.toggle("show", !entry.isIntersecting),
    { threshold: 0.15 }
  ).observe(hero);
} else {
  waFloat.classList.add("show");
}

/* ---------- Contact form ---------- */
const form = $("#contactForm");
const fields = {
  name: $("#name"),
  service: $("#service"),
  message: $("#message"),
};

const rules = {
  name: (v) => (v.length < 2 ? "Please enter your name." : ""),
  service: (v) => (!v ? "Please choose a service." : ""),
  message: (v) =>
    v.length < 10 ? "Please add a few details about your project (at least 10 characters)." : "",
};

function validateField(key) {
  const input = fields[key];
  const msg = rules[key](input.value.trim());
  const out = $(`.error[data-for="${key}"]`);
  out.textContent = msg;
  input.classList.toggle("invalid", Boolean(msg));
  input.setAttribute("aria-invalid", msg ? "true" : "false");
  return !msg;
}

Object.keys(fields).forEach((key) => {
  fields[key].addEventListener("blur", () => validateField(key));
  fields[key].addEventListener("input", () => {
    if (fields[key].classList.contains("invalid")) validateField(key);
  });
});

form.addEventListener("submit", (event) => {
  event.preventDefault();

  const results = Object.keys(fields).map(validateField);
  if (results.includes(false)) {
    const firstBad = Object.values(fields).find((f) => f.classList.contains("invalid"));
    if (firstBad) firstBad.focus();
    return;
  }

  const text =
    `Hello Githaiga, my name is ${fields.name.value.trim()}.\n\n` +
    `I am interested in: ${fields.service.value}.\n\n` +
    `Project details: ${fields.message.value.trim()}`;

  window.open(waLink(text), "_blank", "noopener");
  form.reset();
});
